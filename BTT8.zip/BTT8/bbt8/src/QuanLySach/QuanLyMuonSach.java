package QuanLySach;

import java.util.ArrayList;
import java.util.Scanner;

public class QuanLyMuonSach {
    ArrayList<Muonsach> dsMuon = new ArrayList<>();

    public void themNguoiMuon() {
        Muonsach m = new Muonsach();
        m.nhap();
        dsMuon.add(m);
        System.out.println("Da them nguoi muon thanh cong!");
    }

    public void hienThiNguoiMuon() {
        if (dsMuon.isEmpty()) {
            System.out.println("Chua co nguoi muon nao!");
            return;
        }
        System.out.printf("%-10s %-20s %-25s %-15s\n", "Ma", "Ten", "Email", "So dien thoai");
        for (Muonsach m : dsMuon) {
            m.xuat();
        }
    }

    public void xoaNguoiMuon(String ma) {
        boolean found = false;
        for (int i = 0; i < dsMuon.size(); i++) {
            if (dsMuon.get(i).maNguoiMuon.equalsIgnoreCase(ma)) {
                dsMuon.remove(i);
                System.out.println("Da xoa nguoi muon co ma: " + ma);
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Khong tim thay ma nguoi muon can xoa!");
    }
}
