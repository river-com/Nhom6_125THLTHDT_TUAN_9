package QuanLySach;

import java.util.List;

public interface IQuanLySach {
    void themSach(Sach sach);
    Sach timKiemSach(String tieuDe);
    boolean xoaSach(String tieuDe);
    void hienThiDanhSach();
}
