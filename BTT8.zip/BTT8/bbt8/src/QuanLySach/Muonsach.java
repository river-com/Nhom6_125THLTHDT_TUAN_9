package QuanLySach;

public class Muonsach {
    public String maNguoiMuon;
    public String tenNguoiMuon;
    public String email;
    public String soDienThoai;

    public Muonsach() {}
    public Muonsach(String ma, String ten, String mail, String sdt) {
        maNguoiMuon = ma;
        tenNguoiMuon = ten;
        email = mail;
        soDienThoai = sdt;
    }

    public void nhap() {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.print("Nhap ma nguoi muon: ");
        maNguoiMuon = sc.nextLine();
        System.out.print("Nhap ten nguoi muon: ");
        tenNguoiMuon = sc.nextLine();
        System.out.print("Nhap email: ");
        email = sc.nextLine();
        System.out.print("Nhap so dien thoai: ");
        soDienThoai = sc.nextLine();
    }

    public void xuat() {
        System.out.printf("%-10s %-20s %-25s %-15s\n", maNguoiMuon, tenNguoiMuon, email, soDienThoai);
    }
}
