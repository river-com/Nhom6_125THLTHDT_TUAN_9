package QuanLySach;

// Giao dien tinh gia ban
public interface IGiaBan {
    double tinhGiaBan();
}
