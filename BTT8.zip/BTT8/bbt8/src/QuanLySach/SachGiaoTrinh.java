package QuanLySach;

// Lop con SachGiaoTrinh ke thua tu Sach
public class SachGiaoTrinh extends Sach {
    private String monHoc;
    private String capDo;

    public SachGiaoTrinh(String tieuDe, String tacGia, double giaCoBan, int soLuong, String viTri, String monHoc, String capDo) {
        super(tieuDe, tacGia, giaCoBan, soLuong, viTri);
        this.monHoc = monHoc;
        this.capDo = capDo;
    }

    // Ghi de phuong thuc tinhGiaBan
    @Override
    public double tinhGiaBan() {
        return giaCoBan * 1.2; // Giao trinh loi nhuan 20%
    }

    // Ghi de phuong thuc kiemTraTonKho
    @Override
    public boolean kiemTraTonKho(int soLuongToiThieu) {
        return soLuong >= soLuongToiThieu;
    }

    // Ghi de phuong thuc capNhatViTri
    @Override
    public void capNhatViTri(String viTriMoi) {
        this.viTri = viTriMoi;
        System.out.println("Da chuyen sach " + tieuDe + " den khu vuc: " + viTriMoi);
    }

    @Override
    public String toString() {
        return "[Giao trinh] " + super.toString() +
               ", Mon hoc: " + monHoc + ", Cap do: " + capDo +
               ", Gia ban: " + tinhGiaBan();
    }
}
