package QuanLySach;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        IQuanLySach quanLy = new QuanLySachImpl();
        QuanLyMuonSach qlMuon = new QuanLyMuonSach(); // thêm quản lý người mượn
        int chon;

        do {
            System.out.println("\n===== MENU QUAN LY SACH =====");
            System.out.println("1. Them sach giao trinh");
            System.out.println("2. Them sach tieu thuyet");
            System.out.println("3. Hien thi danh sach sach");
            System.out.println("4. Tim kiem sach");
            System.out.println("5. Xoa sach");
            System.out.println("6. THEM NGUOI MUON SACH");
            System.out.println("7. HIEN THI DANH SACH NGUOI MUON");
            System.out.println("8. XOA NGUOI MUON");
            System.out.println("0. Thoat");
            System.out.print("Chon: ");
            chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {
                case 1:
                    System.out.print("Tieu de: ");
                    String td1 = sc.nextLine();
                    System.out.print("Tac gia: ");
                    String tg1 = sc.nextLine();
                    System.out.print("Gia co ban: ");
                    double gb1 = sc.nextDouble();
                    System.out.print("So luong: ");
                    int sl1 = sc.nextInt(); sc.nextLine();
                    System.out.print("Vi tri: ");
                    String vt1 = sc.nextLine();
                    System.out.print("Mon hoc: ");
                    String mh = sc.nextLine();
                    System.out.print("Cap do: ");
                    String cd = sc.nextLine();

                    quanLy.themSach(new SachGiaoTrinh(td1, tg1, gb1, sl1, vt1, mh, cd));
                    break;

                case 2:
                    System.out.print("Tieu de: ");
                    String td2 = sc.nextLine();
                    System.out.print("Tac gia: ");
                    String tg2 = sc.nextLine();
                    System.out.print("Gia co ban: ");
                    double gb2 = sc.nextDouble();
                    System.out.print("So luong: ");
                    int sl2 = sc.nextInt(); sc.nextLine();
                    System.out.print("Vi tri: ");
                    String vt2 = sc.nextLine();
                    System.out.print("The loai: ");
                    String tl = sc.nextLine();
                    System.out.print("Co phai series (true/false): ");
                    boolean ls = sc.nextBoolean();

                    quanLy.themSach(new SachTieuThuyet(td2, tg2, gb2, sl2, vt2, tl, ls));
                    break;

                case 3:
                    quanLy.hienThiDanhSach();
                    break;

                case 4:
                    System.out.print("Nhap tieu de can tim: ");
                    String tim = sc.nextLine();
                    Sach s = quanLy.timKiemSach(tim);
                    if (s != null) System.out.println("Tim thay: " + s);
                    else System.out.println("Khong tim thay sach.");
                    break;

                case 5:
                    System.out.print("Nhap tieu de can xoa: ");
                    String xoa = sc.nextLine();
                    if (!quanLy.xoaSach(xoa))
                        System.out.println("Khong tim thay sach de xoa.");
                    break;

                case 6:
                    qlMuon.themNguoiMuon();
                    break;

                case 7:
                    qlMuon.hienThiNguoiMuon();
                    break;

                case 8:
                    System.out.print("Nhap ma nguoi muon can xoa: ");
                    String ma = sc.nextLine();
                    qlMuon.xoaNguoiMuon(ma);
                    break;

                case 0:
                    System.out.println("Thoat chuong trinh!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }
        } while (chon != 0);

        sc.close();
    }
}
