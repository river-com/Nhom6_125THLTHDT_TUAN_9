import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        IQuanLySach ql = new QuanLySachImpl();

        int choice;
        do {
            System.out.println("\n===== MENU QUAN LY SACH =====");
            System.out.println("1. Them sach");
            System.out.println("2. Hien thi danh sach");
            System.out.println("3. Tim kiem sach theo ma");
            System.out.println("4. Xoa sach theo ma");
            System.out.println("5. Cap nhat so luong");
            System.out.println("6. Cap nhat thong tin");
            System.out.println("7. Cho muon sach");
            System.out.println("8. Tra sach");
            System.out.println("0. Thoat");
            System.out.print("Nhap lua chon: ");
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    System.out.println("\n-- Them sach moi --");
                    System.out.println("1. Sach giao trinh");
                    System.out.println("2. Sach tieu thuyet");
                    System.out.print("Chon loai sach: ");
                    int loai = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nhap ma sach: ");
                    String bookID = sc.nextLine();
                    System.out.print("Nhap tieu de: ");
                    String title = sc.nextLine();
                    System.out.print("Nhap nam xuat ban: ");
                    int year = sc.nextInt();
                    System.out.print("Nhap so luong: ");
                    int quantity = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nhap vi tri tren ke: ");
                    String position = sc.nextLine();
                    System.out.print("Nhap gia co ban: ");
                    double gia = sc.nextDouble();
                    sc.nextLine();
                    Sach sach = null;
                    if (loai == 1) {
                        System.out.print("Nhap mon hoc: ");
                        String subject = sc.nextLine();
                        System.out.print("Nhap trinh do: ");
                        String academicLevel = sc.nextLine();
                        sach = new SachGiaoTrinh(bookID, title, year, quantity, position, gia, subject, academicLevel);
                    } else if (loai == 2) {
                        System.out.print("Nhap the loai: ");
                        String theLoai = sc.nextLine();
                        sach = new SachTieuThuyet(bookID, title, year, quantity, position, gia, theLoai);
                    } else {
                        System.out.println("Loai sach khong hop le!");
                    }
                    if (sach != null) {
                        ql.themSach(sach);
                        System.out.println("Da them sach thanh cong!");
                    }
                    break;
                case 2:
                    ql.hienthiDanhSach();
                    break;
                case 3:
                    System.out.print("Nhap ma sach can tim: ");
                    bookID = sc.nextLine();
                    ql.timKiemSach(bookID);
                    break;
                case 4:
                    System.out.print("Nhap ma sach can xoa: ");
                    bookID = sc.nextLine();
                    ql.xoaSach(bookID);
                    break;
                case 5:
                    System.out.print("Nhap ma sach can cap nhat so luong: ");
                    bookID = sc.nextLine();
                    System.out.print("Nhap so luong moi: ");
                    quantity = sc.nextInt();
                    sc.nextLine();
                    ql.capNhatsoLuong(bookID, quantity);
                    break;
                case 6:
                    System.out.print("Nhap ma sach can cap nhat: ");
                    bookID = sc.nextLine();
                    System.out.print("Nhap tieu de moi: ");
                    title = sc.nextLine();
                    System.out.print("Nhap nam xuat ban moi: ");
                    year = sc.nextInt();
                    System.out.print("Nhap gia co ban moi: ");
                    gia = sc.nextDouble();
                    sc.nextLine();
                    ql.capNhapThongTin(bookID, title, year, gia);
                    break;

                case 7:
                    System.out.print("Nhap ma sach can cho muon: ");
                    bookID = sc.nextLine();
                    System.out.print("Nhap so luong muon: ");
                    quantity = sc.nextInt();
                    sc.nextLine();
                    ql.choMuonSach(bookID, quantity);
                    break;

                case 8:
                    System.out.print("Nhap ma sach can tra: ");
                    bookID = sc.nextLine();
                    System.out.print("Nhap so luong tra: ");
                    quantity = sc.nextInt();
                    sc.nextLine();
                    ql.traSach(bookID, quantity);
                    break;

                case 0:
                    System.out.println("Thoat chuong trinh. Tam biet!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }

        } while (choice != 0);

        sc.close();
    }
}
