public class SachTieuThuyet extends Sach {
    private String theLoai;
    private boolean SachSeries;
    public SachTieuThuyet(String bookID, String title,int publicationyear, int quantity,String position, double giaCoBan, String theLoai) {
        super(bookID, title,publicationyear, quantity,position, giaCoBan);
        this.theLoai = theLoai;
    }
    public String getTheLoai() {
        return theLoai;
    }   
    public void setTheLoai(String theLoai) {
        this.theLoai = theLoai;
    }
    @Override
    public String toString() {
        return "SachTieuThuyet:" +
                "bookID=" + getBookID() + "\n" +
                "title=" + getTitle() + "\n" +
                "theLoai=" + theLoai + "\n" +
                "SachSeries=" + this.SachSeries + "\n" +
                "position=" + getPosition() + "\n" +
                "gia co ban=" + getGiaCoBan()+" VND \n";        
    }
    @Override
    public double tinhGiaBan() {
        if (SachSeries) {
            return getGiaCoBan() + 15000; 
        } else {
            return getGiaCoBan();
        }
    }
    @Override
    public void capNhatViTri(String viTriMoi) {
        setPosition(viTriMoi);
        System.out.println("Da chuyen sach" + getTitle() + "den vi tri moi: " + viTriMoi);
    }
    
}