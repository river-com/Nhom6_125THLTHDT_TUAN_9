public interface IQuanLySach {
    void themSach(Sach sach);
    void timKiemSach(String bookID);
    void xoaSach(String bookID);
    void hienthiDanhSach();
    void capNhatsoLuong(String bookID, int soLuongMoi);
    void capNhapThongTin(String bookID, String title, int publicationyear,double giaCoBan);
    void choMuonSach(String bookID, int soLuongMuon);
    void traSach(String bookID, int soLuongTra);
    
}
