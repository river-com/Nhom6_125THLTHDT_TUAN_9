public abstract class Sach implements IGiaBan, IKiemKe {
    private String bookID;
    private String title;
    private int publicationyear;
    private int quantity;
    private String position;
    private double giaCoBan;
    public Sach(String bookID, String title,int publicationyear, int quantity, String position, double giaCoBan) {
        this.bookID = bookID;
        this.title = title;
        this.publicationyear = publicationyear;
        this.quantity = quantity;
        this.position = position;
        this.giaCoBan = giaCoBan;
    }

    public String getBookID() {
        return this.bookID;
    }

    public void setBookID(String bookID) {
        this.bookID = bookID;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPublicationyear() {
        return this.publicationyear;
    }

    public void setPublicationyear(int publicationyear) {
        this.publicationyear = publicationyear;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
     public int getQuantity() {
        return this.quantity;
    }

    public void setPosition(String position) {
        this.position = position;
    }
    public String getPosition() {
        return this.position;
    }
    public double getGiaCoBan() {
        return this.giaCoBan;
    }
    public void setGiaCoBan(double giaCoBan) {
        this.giaCoBan = giaCoBan;
    }
    @Override
    public boolean kiemTraTonKho(int soLuongToiThieu) {
        return getQuantity() >= soLuongToiThieu;
    }


    
}
