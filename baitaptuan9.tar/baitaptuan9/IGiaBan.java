public interface  IGiaBan {
    double tinhGiaBan();
}