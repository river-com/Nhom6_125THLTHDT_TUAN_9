import java.util.List;
import java.util.ArrayList;

public class QuanLySachImpl implements IQuanLySach {
    private List<Sach> danhSach;

    public QuanLySachImpl(){
        this.danhSach = new ArrayList<>();
    }
    @Override
    public void themSach(Sach sach) {
        for(Sach s : danhSach){
            if(s.getBookID().equals(sach.getBookID())){
                System.out.println("Bi trung ma sach " + sach.getBookID());
                return;
            }
        }
        danhSach.add(sach );
    }
    @Override
    public void hienthiDanhSach(){
        for(Sach sach : danhSach){
            System.out.println(sach.toString());
        }
    }
    @Override
    public void timKiemSach(String bookID){
        for(Sach sach : danhSach){
            if(sach.getBookID().equals(bookID)){
                System.out.println(sach.toString());
                return;
            }
        }
        System.out.println("Khong tim thay sach voi ma: " + bookID);
    }
    @Override
    public void xoaSach(String bookID){
        for(Sach sach : danhSach){
            if(sach.getBookID().equals(bookID)){
                danhSach.remove(sach);
                System.out.println("Da xoa sach voi ma: " + bookID);
                return;
            }
        }
        System.out.println("Khong tim thay sach voi ma: " + bookID);
    }
    @Override
    public void capNhatsoLuong(String bookID, int soLuongMoi){
        for(Sach sach : danhSach){
            if(sach.getBookID().equals(bookID)){
                sach.setQuantity(soLuongMoi);
                System.out.println("Da cap nhat so luong sach voi ma: " + bookID + " thanh " + soLuongMoi);
                return;
            }
        }
        System.out.println("Khong tim thay sach voi ma: " + bookID);
    }
    @Override
    public void capNhapThongTin(String bookID, String title, int publicationyear,double giaCoBan){
        for(Sach sach : danhSach){
            if(sach.getBookID().equals(bookID)){
                sach.setTitle(title);
                sach.setPublicationyear(publicationyear);
                sach.setGiaCoBan(giaCoBan);
                return;
            }
        }
        System.out.println("Khong tim thay sach voi ma: " + bookID);
    }
    @Override 
    public void choMuonSach(String bookID, int soLuongMuon){
        for(Sach sach : danhSach){
            if(sach.getBookID().equals(bookID)){
                if(sach.getQuantity() >= soLuongMuon){
                    sach.setQuantity(sach.getQuantity() - soLuongMuon);
                    System.out.println("Da cho muon " + soLuongMuon + " cuon sach voi ma: " + bookID);
                } else {
                    System.out.println("Khong du so luong de cho muon sach voi ma: " + bookID);
                }
                return;
            }
        }
        System.out.println("Khong tim thay sach voi ma: " + bookID);
    }
    @Override
    public void traSach(String bookID, int soLuongTra){
        for(Sach sach : danhSach){
            if(sach.getBookID().equals(bookID)){
                sach.setQuantity(sach.getQuantity() + soLuongTra);
                System.out.println("Da tra " + soLuongTra + " cuon sach voi ma: " + bookID);
                return;
            }
        }
        System.out.println("Khong tim thay sach voi ma: " + bookID);
    }
}



