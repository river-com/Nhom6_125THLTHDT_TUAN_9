public class SachGiaoTrinh extends Sach{
    private String subject;
    private String academicLevel;

    public SachGiaoTrinh(String bookID, String title,int publicationyear, int quantity,String position, double giaCoBan, String subject, String academicLevel) {
        super(bookID, title,publicationyear, quantity,position, giaCoBan);
        this.subject = subject;
        this.academicLevel = academicLevel;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getAcademicLevel() {
        return academicLevel;
    }

    public void setAcademicLevel(String academicLevel) {
        this.academicLevel = academicLevel;
    }
    @Override
    public double tinhGiaBan() {
        return getGiaCoBan() + ((2025 - getPublicationyear()) * 5000); 
    }
    @Override
    public String toString() {
        return "SachGiaoTrinh:" +
                "bookID=" + getBookID() + "\n" +
                "title=" + getTitle() + "\n" +
                "subject=" + subject + "\n" +
                "academicLevel=" + academicLevel + "\n" +
                "position=" + getPosition() + "\n" +
                "gia ban=" + tinhGiaBan()+" VND \n" ;        
    }
    @Override
    public void capNhatViTri(String viTriMoi) {
        setPosition(viTriMoi);
        System.out.println("Da chuyen sach" + getTitle() + "den vi tri moi: " + viTriMoi);
    }
}
